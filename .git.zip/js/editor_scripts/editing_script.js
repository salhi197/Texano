$(document).ready(function () {

    let tableHtml = "<table class='table table-bordered'>";
    let editorText = document.getElementById('editor').innerText;
    let editor = document.getElementById('editor');
    let responseData;
    new Medium({
        element: document.getElementById('editor'),
        // placeholder: "Type a text here",
        autofocus: true,
        autoHR: false,
        mode: Medium.richMode,
        keyContext: null,

    });


    $("button").click(function () {
        const which = $(this).data("which");

        if (which == "findData") {
            let elementChecked = pushChecks();

            tokenResponse(editor.medium.element.innerText).then(result => {
                if (elementChecked) {
                    detectEntities(result, false)
                    console.log(result);
                }
                else {
                    alert('Please select a category to anonymize');
                }
                // document.getElementById("editorContentHTML").value = document.getElementById("editor").innerHTML;
            });
        }

        else if (which == "anoynmizeData") {
            let elementChecked = pushChecks();

            tokenResponse(editor.medium.element.innerText).then(result => {
                if (elementChecked) {
                    detectEntities(result, true)
                }
                else {
                    alert('Please select a category to anonymize');
                }

                // document.getElementById("editorContentHTML").value = document.getElementById("editor").innerHTML;

            });

        } // end AnoPerNames


    }); // end button click


    function tokenResponse(editorText) {
        return new Promise(
            function (resolve, reject) {
                let result = '';
                $.ajax({
                    type: "POST",
                    url: "http://corenlp.run/?properties=%7B%22annotators%22%3A%20%22tokenize%2Cssplit%2Cner%22%2C%20%22date%22%3A%20%222018-12-24T17%3A30%3A59%22%7D&pipelineLanguage=en",
                    async: "true",
                    // data: "sentence=" + editorText,
                    data: editorText,
                    success: resolve,
                    error: reject
                });
            })
    }

    function checkBoxes() {
        let checkedElements = new Array();
        $("input:checkbox[name=selectionFilter]:checked").each(function () {
            checkedElements.push($(this).val());
        });
        return checkedElements;
    }

    function pushChecks() {
        let checkedElements = checkBoxes();

        if (checkedElements.length > 0) {
            return true;
        }
        else return false;
    }


    function detectEntities(array, anonymize) {

        let result = '';
        var newArray = array.sentences[0].tokens;
        let checkedElements = checkBoxes();
        newArray.forEach((element, index, array) => {
            var word = element.word;
            var tag = element.ner;
            var position = element.index;

            pushChecks();

            if (word != "-LRB-" && word != "-RRB-") {

                if ($.inArray(tag, checkedElements) > -1) {
                    if (!anonymize) {
                        result = getDetectResult(tag, result, word, position);
                    }
                    else {
                        result = getAnoymizeResult(tag, result, word, position);
                    }
                }

                else {
                    result += word + " ";
                }

            }

        })
        $("#editor").html(" ");
        $("#editor").html(result);
        initializeTooltipNameOfPerson();

    }


    $('#returnOldValue').click(function () {
        var parent_id = $(this).parent().attr('id');
        var toChangeElement = $(parent_id).att('data-word');
        console.log(parent_id);
        console.log(toChangeElement);
    });


});


function colorEntitiesAnoynmize(word, result, color, title, position) {

    dataContent = buildHtml(position, word, title, true);


    word = "<span class='namePerson' "
        + "style='color:" + color + ";' "
        + "id= 'p" + position + "'"
        + "data-html='true' "
        + "data-tippy-content='" + dataContent + "' "
        + "data-word='" + word + "'" + "'> "
        + "X"
        + "</span>";
    result += word + " ";
    return result;
}

function buildHtml(position, word, title, anonymize) {

    result =
        "<div class=\"card\" style=\"width: 18rem;\">" +
        "<div class=\"card-header\ style=\"color:blue\">" + title + "</div>" +
        "<div class=\"list-group\">";

    if (anonymize) {
        var add = "<a href=\"#!\" class=\"list-group-item active list-group-item-action\" id =\"p" + position + "\" onclick=\"returnOldValue(this)\">Return to: <strong>" + word + "</strong></a>";
        result = result + add;
    }
    else {
        var add = "<a href=\"#!\" class=\"list-group-item active list-group-item-action\" id =\"p" + position + "\" onclick=\"makeAnX(this)\">Anonymize this word" + "</a>";
        result = result + add;
    }
    result = result + "</div>" + "</div>";

    return result
}

function colorEntitiesDetect(word, result, color, title, position) {
    dataContent = buildHtml(position, word, title, false);
    word = "<span class='namePerson' "
        + "style='color:" + color + ";' "
        + "id= 'p" + position + "'"
        + "data-html='true' "
        + "data-tippy-content='" + dataContent + "' "
        + "title='" + title + "'>"
        + word
        + "</span>";
    result += word + " ";
    return result;
}

function getDetectResult(tag, result, word, position) {
    if (tag == "PERSON") {
        result = colorEntitiesDetect(word, result, "red", "Name Of Person", position);
    }
    else if (tag == "COUNTRY") {
        result = colorEntitiesDetect(word, result, "blue", "Name of Country", position);
    }

    else if (tag == "NUMBER") {
        result = colorEntitiesDetect(word, result, "orange", "A Number", position)
    }

    else if (tag == "MONEY") {
        result = colorEntitiesDetect(word, result, "green", "Money", position)
    }

    else if (tag == "DATE") {
        result = colorEntitiesDetect(word, result, "purple", "Date or time", position)
    }
    return result;
}

function getAnoymizeResult(tag, result, word, position) {
    if (tag == "PERSON") {
        result = colorEntitiesAnoynmize(word, result, "red", "Name Of Person", position);
    }
    else if (tag == "COUNTRY") {
        result = colorEntitiesAnoynmize(word, result, "blue", "Name of Country", position);
    }

    else if (tag == "NUMBER") {
        result = colorEntitiesAnoynmize(word, result, "orange", "A Number", position)
    }

    else if (tag == "MONEY") {
        result = colorEntitiesAnoynmize(word, result, "green", "Money", position)
    }

    else if (tag == "DATE") {
        result = colorEntitiesAnoynmize(word, result, "purple", "Date or time", position)
    }
    return result;
}

function initializeTooltipNameOfPerson() {
    tippy('.namePerson', {
        // content: document.querySelector('#template1').innerHTML,
        delay: 100,
        arrow: true,
        arrowType: 'round',
        size: 'large',
        duration: 500,
        animation: 'scale',
        interactive: true,
        theme: "light"
    });
}

function returnOldValue(element) {
    // get the clicked element and append it with the saved attribute in span and make it back again
    var spanElement = document.getElementById(element.id);
    var elementOldValue = spanElement.getAttribute("data-word");
    spanElement.innerHTML = elementOldValue;
    spanElement.style = 'color:black;';
}

function makeAnX(element) {
    var spanElement = document.getElementById(element.id);
    spanElement.innerHTML = "X";
    spanElement.style = 'color:black;'
}

