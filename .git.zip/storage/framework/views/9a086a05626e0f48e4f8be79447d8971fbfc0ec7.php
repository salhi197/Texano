<?php echo $__env->make('partials.libraries', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container" xmlns="http://www.w3.org/1999/html">

        <div class="row">
            <div class="col-lg-8">
                <h3>New Text</h3>
            </div>
        </div>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong> There was some problems with the input</strong>
                <ul>
                    <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('text.store')); ?>" method="post" onsubmit="return getContent()" id="storeForm">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-lg-8">
                <div class="col-md-12">
                    <strong>Text titel</strong>
                    <input class="form-control" placeholder="Type your titel here" name="titel" required/>
                </div>
                <div class="col-md-12">
                    <strong>Text data</strong>
                    <!-- because div element doesn't submit values, I use a hidden textarea to submit its content see getContent function -->
                    <div id="editor" contenteditable="true" required></div>
                    <textarea id="editorContentHTML" style="display:none" name="html_data"></textarea>
                    <textarea id="editorContentText" style="display:none" name="text_data"></textarea>
                </div>

                <div class="col-md-12" style="margin-top: 10px;">
                    <a href="<?php echo e(route('text.index')); ?>" class="btn btn-sm btn-success">Back</a>
                    <button type="submit" class="btn btn-sm btn-primary">Save</button>
                </div>
            </div>
                <div class="col-lg-4">
                    <?php $__env->startSection('editorconrols'); ?>
                        <?php echo $__env->make('partials.editorcontrols', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php $__env->stopSection(); ?>

                    <script type="javascript" src="<?php echo e(asset('js/mdb.js')); ?>"></script>
                    <?php $__env->stopSection(); ?>
                </div>
            </div>
        </form>

        <script>
            function getContent() {
                var editor = document.getElementById("editor");
                var editorHTML = document.getElementById("editorContentHTML");
                var editorText = document.getElementById("editorContentText");

                editorHTML.value = editor.innerHTML;
                editorText.value = document.getElementById("editor").innerText;
            }
            // $('#storeForm').parsley();
        </script>

    </div>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>