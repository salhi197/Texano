<script src="https://unpkg.com/tippy.js@3/dist/tippy.all.min.js"></script>
<script src="<?php echo e(asset('js/tippyScript.js')); ?>"></script>
<script src="<?php echo e(asset('js/rangy-core.js')); ?>"></script>
<script src="<?php echo e(asset('js/rangy-classapplier.js')); ?>"></script>
<script src="<?php echo e(asset('js/undo.js')); ?>"></script>
<script src="<?php echo e(asset('js/medium.js')); ?>"></script>
<link rel="stylesheet" href="<?php echo e(asset('css/medium.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/mdb.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/parsley.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/tippy/tippy.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/tippy/themes/light.css')); ?>">

<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<!-- Font Awesome -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<!-- Bootstrap CSS -->
<link rel="stylesheet"
      href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css"
      integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">

<!--<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>


<script src="<?php echo e(asset('js/editor_scripts/editing_script.js')); ?>"></script>
<script src="<?php echo e(asset('js/parsley.min.js')); ?>"></script>

<script type="text/javascript">
	            function clearFile() {
              $('#clear').click(function() {
                $("#myFile").val("");
              }); 
                $("#custom-text").val('')  
                $("#editor").html('')                 
                                 
                console.log('[cleaning the file ]'+$("#myFile").val())
                               
            }
            function WriteFileNameInInput(event) {
                var fileInput = document.getElementById('myFile');   
                var filename = fileInput.files[0].name;
                $("#custom-text").val(filename)

                 var input = event.target;
                var reader = new FileReader();
                reader.onload = function(){
                  var text = reader.result;
                  var node = document.getElementById('editor');
                  node.innerHTML = text;
//                  console.log(reader.result.substring(0, 200));
                };
                reader.readAsText(input.files[0]);

              }            

            // $('#storeForm').parsley();
            function getFile() {
               if ($("#editor").html()!='') {

	              var text=$("#editor").html()
	               console.log(text)
                    name=$("#custom-text").val()
	                  type='text/plain' 
	              // var file = new Blob([text], {type: type});	
	              // $('#download').attr('href',URL.createObjectURL(file))               	
               }else{
               	alert('[Fields empty .. ]')
               }
            }

</script>