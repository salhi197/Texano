<script src="https://unpkg.com/tippy.js@3/dist/tippy.all.min.js"></script>
<script src="{{ asset('js/tippyScript.js') }}"></script>
<script src="{{ asset('js/rangy-core.js') }}"></script>
<script src="{{ asset('js/rangy-classapplier.js') }}"></script>
<script src="{{ asset('js/undo.js') }}"></script>
<script src="{{ asset('js/medium.js') }}"></script>
<link rel="stylesheet" href="{{ asset('css/medium.css') }}">
<link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('css/mdb.min.css') }}">
<link rel="stylesheet" href="{{ asset('css/parsley.css') }}">
<link rel="stylesheet" href="{{ asset('css/style.css') }}">
<link rel="stylesheet" href="{{ asset('css/tippy/tippy.css') }}">
<link rel="stylesheet" href="{{ asset('css/tippy/themes/light.css') }}">

<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<!-- Font Awesome -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<!-- Bootstrap CSS -->
<link rel="stylesheet"
      href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css"
      integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">

<!--<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>


<script src="{{ asset('js/editor_scripts/editing_script.js') }}"></script>
<script src="{{asset('js/parsley.min.js')}}"></script>

<script src="{{asset('js/docxgen.min.js')}}"></script>
<script src="{{asset('js/FileSaver.min.js')}}"></script>
<script src="{{asset('js/jszip-utils.js')}}"></script>


    <script src="https://unpkg.com/docx@4.0.0/build/index.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/1.3.8/FileSaver.js"></script>

<script type="text/javascript">
	            function clearFile() {
              $('#clear').click(function() {
                $("#myFile").val("");
              }); 
                $("#custom-text").val('')  
                $("#editor").html('')                 
                                 
                console.log('[cleaning the file ]'+$("#myFile").val())
                               
            }
            function readFile(event) {

                 var myFile = document.getElementById('myFile').files[0];
                //get uploaded file ...
                var fichier= window.URL.createObjectURL(myFile)
                //get file extension
                var ext = myFile.name.split('.').pop();
                console.log('[extension..]'+ext);
                //get filename and put it into the file name input 
                var filename = myFile.name;
                console.log('[Adding file name to input..]');
                $("#custom-text").val(filename)
                //if the file is a .docx , do this treatmant , put its contetn in the textarea 
                if(ext!='docx'){
                    alert('the format should be .docx')
                    clearFile()
                }  
                    var loadFile=function(url,callback){
                        JSZipUtils.getBinaryContent(url,callback);
                    }
                        loadFile(fichier,function(err,content){
                            var doc=new Docxgen(content);
                            text=doc.getFullText();
                            var node = document.getElementById('editor');
                             node.innerHTML = text;
                            console.log(text);
                        });          
                    return 0;
              }            

            $('#storeForm').parsley();
            
            
            
            
            
            //generate & download docx file 
        function getFile() {
if ($("#editor").html()=='') {

    alert('[ no file selected ]')
    return 0;
    
}    
            const doc = new Document();

            const paragraph = new Paragraph($("#editor").text());
            doc.addParagraph(paragraph);
            const packer = new Packer();

            packer.toBlob(doc).then(blob => {
                console.log(blob);
                saveAs(blob, "example.docx");
                console.log("Document created successfully");
            });
        }            


</script>