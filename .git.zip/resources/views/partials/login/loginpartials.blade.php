
{{--/**--}}
 {{--* Created by PhpStorm.--}}
 {{--* User: Anouar--}}
 {{--* Date: 28.01.2019--}}
 {{--* Time: 21:42--}}
 {{--*/--}}

{{--<link rel = "icon" type = "image/png" href = "images/icons/favicon.ico">--}}
{{--<link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}">--}}
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel = "stylesheet" type = "text/css" href = "{{asset('css/iconic/css/material-design-iconic-font.min.css')}}">
<link rel="stylesheet" href="{{asset('css/animate-css/animate.css')}}">
<link rel = "stylesheet" type = "text/css" href = "{{asset('css/css-hamburgers/hamburgers.css')}}">
{{--<link rel = "stylesheet" type = "text/css" href = "vendor/animsition/css/animsition.css" >--}}
{{--<link rel = "stylesheet" type = "text/css" href = "{{asset('vendor/select2/select2.min.css')}}" >--}}
{{--<link rel = "stylesheet" type = "text/css" href = "{{asset('vendor/daterangepicker/daterangepicker.css')}}" >--}}
<link rel = "stylesheet" type = "text/css" href = "{{asset('css/util.css')}}">
<link rel = "stylesheet" type = "text/css" href = "{{asset('css/main.css')}}">


{{--<link rel="stylesheet" href="{{ asset('css/tippy/themes/light.css') }}">--}}
