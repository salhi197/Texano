    <h3>Data Controls</h3>

    <div class="mb-4">
        <button data-which="findData" type="button" class="btn btn-primary btn-sm">Find sensitive data</button>
        <button data-which="anoynmizeData" type="button" class="btn btn-primary btn-sm">Anonymize Data</button>
        <a href="javascript:void(0)" id="download" class="btn btn-sm btn-primary" onclick="getFile()" download>download</a>

    </div>

    <div class="mb-8">
        <div>
            <h3>Filter Controls</h3>
            <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="PersNamesCheck" name="selectionFilter"
                       value="PERSON" checked>
                <label class="custom-control-label" for="PersNamesCheck">Names of Persons</label>
            </div>
            <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="DateCheck" name="selectionFilter"
                       value="DATE" checked>
                <label class="custom-control-label" for="DateCheck">Date and time</label>
            </div>
            <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="CountriesCheck" name="selectionFilter"
                       value="COUNTRY" checked>
                <label class="custom-control-label" for="CountriesCheck">Countries</label>
            </div>

            <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="NumbersCheck" name="selectionFilter"
                       value="NUMBER" checked>
                <label class="custom-control-label" for="NumbersCheck">Numbers</label>
            </div>

            <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="MoneyCheck" name="selectionFilter"
                       value="MONEY" checked>
                <label class="custom-control-label" for="MoneyCheck">Money</label>
            </div>
        </div>

    </div>
