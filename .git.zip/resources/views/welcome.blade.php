<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="img/favicon.ico" type="image/png">
    <title>Texano</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/linericon/style.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/owl-carousel/owl.carousel.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/nice-select/css/nice-select.css">
    <link rel="stylesheet" href="css/animate-css/animate.css">
    <link rel="stylesheet" href="css/flaticon/flaticon.css">
    <!-- main css -->
    <link rel="stylesheet" href="css/style_home.css">
</head>

<body>

<!--================Header Menu Area =================-->
<header class="header_area">
    <div class="main_menu">
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <a class="navbar-brand logo_h" href="#"><img src="img/logo_new.png" alt=""></a>
                @if (Route::has('login'))
                    <div class="topnav-right">
                        @auth
                            <a class="links-right" href="{{ url('/home') }}">Home</a>
                        @else
                            <a class="links-right" href="{{ route('login') }}">Login</a>

                            @if (Route::has('register'))

                                <a class="links-right" href="{{ route('register') }}">Register</a>

                            @endif
                        @endauth
                    </div>
                @endif
            </div>
        </nav>
    </div>
</header>


<!--================Home Banner Area =================-->
<section class="home_banner_area">
    <div class="banner_inner">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <div class="banner_content">
                        <h2>
                            Anonymize any text data
                        </h2>
                        <p>
                            Texano is the first web-app to analyze text and gives insights about sensitive data and
                            provide anonymization for it. ALL FREE for a limited time !
                        </p>
                        <div class="d-flex align-items-center">
                            <a class="primary_btn" href="{{ route('register') }}"><span>Get Started</span></a>
                            <a id="play-home-video" class="video-play-button"
                               href="https://www.youtube.com/watch?v=cy6csTnsKLY">
                                <span></span>
                            </a>
                            <div class="watch_video text-uppercase">
                                watch the video
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="home_right_img">
                        <img class="img-fluid" src="img/newComputer.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<!--&lt;!&ndash;================Footer Area =================&ndash;&gt;-->
<footer class="footer_area">
    <div class="container">
        <div class="row footer_inner">
            <div class="col-lg-5 col-sm-6">
                <aside class="f_widget ab_widget">
                    <div class="f_title">
                        <h3>About Me</h3>
                    </div>

                    <p>
                        Copyright &copy;<script>document.write(new Date().getFullYear());</script>
                        All rights reserved | This App is made with <i class="fa fa-heart-o" aria-hidden="true"></i> in
                        Frankfurt.</a>
                        Landing page using <a href="https://colorlib.com/">Colorlib</a>
                    </p>
                </aside>
            </div>
            <div class="col-lg-5 col-sm-6">
                <aside class="f_widget news_widget">
                    <div class="f_title">
                        <h3>Newsletter</h3>
                    </div>
                    <p>Stay updated with our latest trends</p>
                    <div id="mc_embed_signup">
                        <form target="_blank"
                              action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01"
                              method="get" class="subscribe_form relative">
                            <div class="input-group d-flex flex-row">
                                <input name="EMAIL" placeholder="Enter email address" onfocus="this.placeholder = ''"
                                       onblur="this.placeholder = 'Email Address '"
                                       required="" type="email">
                                <button class="btn sub-btn"><span class="lnr lnr-arrow-right"></span></button>
                            </div>
                            <div class="mt-10 info"></div>
                        </form>
                    </div>
                </aside>
            </div>
            <div class="col-lg-2">
                <aside class="f_widget social_widget">
                    <div class="f_title">
                        <h3>Follow Me</h3>
                    </div>
                    <p>Let us be social</p>
                    <ul class="list">
                        <li><a href="https://www.linkedin.com/in/anwar-benhamada-831896129/"><i
                                        class="fa fa-linkedin"></i></a></li>
                    </ul>
                </aside>
            </div>
        </div>
    </div>
</footer>
<!--================End Footer Area =================-->

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/popper.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/stellar.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/nice-select/js/jquery.nice-select.min.js"></script>
<script src="js/isotope/imagesloaded.pkgd.min.js"></script>
<script src="js/isotope/isotope-min.js"></script>
<script src="css/owl-carousel/owl.carousel.min.js"></script>
<script src="js/jquery.ajaxchimp.min.js"></script>
<script src="js/counter-up/jquery.waypoints.min.js"></script>
<script src="js/counter-up/jquery.counterup.min.js"></script>
<script src="js/mail-script.js"></script>
<!--gmaps Js-->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCjCGmQ0Uq4exrzdcL6rvxywDDOvfAu6eE"></script>
<script src="js/gmaps.min.js"></script>
<script src="js/theme.js"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-131917443-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'UA-131917443-1');
</script>
</body>

</html>