@extends('layouts.app')
@include('partials.libraries')
@section('content')

    <div class="container" xmlns="http://www.w3.org/1999/html">

        <div class="row">
            <div class="col-lg-8">
                <h3>New Text</h3>
            </div>
        </div>
        @if($errors->any())
            <div class="alert alert-danger">
                <strong> There was some problems with the input</strong>
                <ul>
                    @foreach($errors as $error)
                        <li>{{$error}}</li>
                    @endforeach
                </ul>
            </div>
        @endif
            <div class="col-md-12" style="margin-top: 10px;">
                <input type="file" name="filename" id="myFile" hidden="true" onchange="readFile(event)" accept=".docx, .txt">
                <label for="myFile" class="btn btn-sm btn-info">Upload File</label>
                <button id="clear" onclick="clearFile()" class="btn btn-sm btn-warning">Remove File</button>
             
            </div>          

        <form action="{{route('text.store')}}" method="post" onsubmit="return getContent()" id="storeForm">
            @csrf
            <div class="row">
                <div class="col-lg-8">
                <div class="col-md-12">
                    <strong>Text titel</strong>
                    <input class="form-control"  id="custom-text" placeholder="Type your titel here" name="titel" required/>
                </div>
                <div class="col-md-12">
                    <strong>Text data</strong>
                    <!-- because div element doesn't submit values, I use a hidden textarea to submit its content see getContent function -->
                    <div id="editor" contenteditable="true" required></div>
                    <textarea id="editorContentHTML" style="display:none" name="html_data"></textarea>
                    <textarea id="editorContentText" style="display:none" name="text_data"></textarea>
                </div>

                <div class="col-md-12" style="margin-top: 10px;">
                    <a href="{{route('text.index')}}" class="btn btn-sm btn-success">Back</a>
                    <button type="submit" class="btn btn-sm btn-primary">Save</button>

                </div>
            </div>
                <div class="col-lg-4">
                    
                    @section('editorconrols')
                        @include('partials.editorcontrols')

                    @endsection

                    <script type="javascript" src="{{asset('js/mdb.js')}}"></script>
                    @endsection
                </div>
            </div>
        </form>

        <script>

            function getContent() {
                var editor = document.getElementById("editor");
                var editorHTML = document.getElementById("editorContentHTML");
                var editorText = document.getElementById("editorContentText");

                editorHTML.value = editor.innerHTML;
                editorText.value = document.getElementById("editor").innerText;
            }



        </script>

    </div>







                
