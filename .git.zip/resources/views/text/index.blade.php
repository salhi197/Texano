@extends('layouts.app')

@section('content')

    <div class="container">
        <div class="row">
            <div class="col-md-10">
                <h3>List of User Texts</h3>
            </div>
        </div>
        <br>

        <div class="col-sm-2">
            <a class="btn btn-sm btn-success" href="{{route('text.create')}}">Create Text</a>
        </div>

        <br>
        @if($message= Session::get('success'))
            <div class="alert alert-success">
                <p>{{$message}}</p>
            </div>
        @endif

        <table class="table table-hover table-sm">
            <tr>
                <th width="50px"><b>No.</b></th>
                <th width="300px"><b>Titel</b></th>
                <th width="300px"><b>Text Data</b></th>
            </tr>

            @foreach ($texts as $text)
                <tr>
                    <td><b>{{++$i}}.</b></td>
                    <td>{{$text->titel}}</td>
                    <td>{{$text->text_data}}</td>
                    <td>
                        <form action="{{ route('text.destroy', $text->id) }}" method="post">
{{--                            <a class="btn btn-sm btn-success" href="{{route('text.show',$text->id)}}">Show</a>--}}
                            <a class="btn btn-sm btn-warning" href="{{route('text.edit',$text->id)}}">Edit</a>
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </table>
        {!! $texts->links() !!}

    </div>
@endsection