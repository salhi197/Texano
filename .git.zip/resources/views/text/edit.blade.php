@extends('layouts.app')
@include('partials.libraries')
@section('content')

    <div class="container" xmlns="http://www.w3.org/1999/html">

        <div class="row">
            <div class="col-lg-8">
                <h3>New Text</h3>
            </div>
        </div>
        @if($errors->any())
            <div class="alert alert-danger">
                <strong> There was some problems with the input</strong>
                <ul>
                    @foreach($errors as $error)
                        <li>{{$error}}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{route('text.editAndStore', $textdata->id)}}" method="post" onsubmit="return getContent()">
            @csrf
            <div class="row">
                <div class="col-lg-8">
                    <div class="col-md-12">
                        <strong>Text titel</strong>
                        <input class="form-control" placeholder="Type your titel here" value="{{$textdata->titel}}" name="titel" required/>
                    </div>
                    <div class="col-md-12">
                        <strong>Text data</strong>
                        <!-- because div element doesn't submit values, I use a hidden textarea to submit its content see getContent function -->
                        <div id="editor" contenteditable="true" required></div>
                        <textarea id="editorContentHTML" style="display:none" name="html_data"></textarea>
                        <textarea id="editorContentText" style="display:none" name="text_data"></textarea>
                    </div>

                    <div class="col-md-12" style="margin-top: 10px;">
                        <a href="{{route('text.index')}}" class="btn btn-sm btn-success">Back</a>
                        <button type="submit" class="btn btn-sm btn-primary">Save</button>
                    </div>
                </div>
                <div class="col-lg-4">
                    @section('editorconrols')
                        @include('partials.editorcontrols')
                    @endsection

                    <script type="javascript" src="{{asset('js/mdb.js')}}"></script>
                    @endsection
                </div>
            </div>
        </form>

        <script>
            $(document).ready(function () {
                $("#editor").html({!! json_encode($textdata->html_data) !!});
                initializeTooltipNameOfPerson();
            });

            function initializeTooltipNameOfPerson() {
                tippy('.namePerson', {
                    // content: document.querySelector('#template1').innerHTML,
                    delay: 100,
                    arrow: true,
                    arrowType: 'round',
                    size: 'large',
                    duration: 500,
                    animation: 'scale',
                    interactive: true,
                    theme: "light"
                });
            }

        </script>

        <script>
            function getContent() {
                document.getElementById("editorContentHTML").value = document.getElementById("editor").innerHTML;
                document.getElementById("editorContentText").value = document.getElementById("editor").innerText;
            }
        </script>

    </div>

    {{--Anwar Benhamada, 100$, 12 December in USA --}}
